#include <bits/stdc++.h>
using namespace std;

int main() {
    int n = 4;
    int W = 7;

    int wt[] = {1, 3, 4, 5};
    int val[] = {1, 4, 5, 7};

    int dp[n+1][W+1];


    for(int i = 0; i <= n; i++) {
        for(int w = 0; w <= W; w++) {
            if(i == 0 || w == 0)
                dp[i][w] = 0;
            else if(wt[i-1] <= w)
                dp[i][w] = max(val[i-1] + dp[i-1][w-wt[i-1]], dp[i-1][w]);
            else
                dp[i][w] = dp[i-1][w];
        }
    }
    cout << "Maximum value: " << dp[n][W] << endl;


    int w = W;
    vector<int> items;

    for(int i = n; i > 0 && w > 0; i--) {
        if(dp[i][w] != dp[i-1][w]) {
            items.push_back(i);
            w = w - wt[i-1];
        }
    }

    cout << "Objects taken: ";
    reverse(items.begin(), items.end());

    for(int item : items) {
        cout << "Item " << item
             << " (Weight=" << wt[item-1]
             << ", Value=" << val[item-1] << ") ";
    }

    return 0;
}
