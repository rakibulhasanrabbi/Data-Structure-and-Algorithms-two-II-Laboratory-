#include <bits/stdc++.h>
using namespace std;

int main() {
    vector<int> coins = {1, 3, 4};
    int amount = 6;

    vector<int> dp(amount + 1, INT_MAX);
    vector<int> chosen(amount + 1, -1);
    dp[0] = 0;

    for (int a = 1; a <= amount; a++) {
        for (int coin : coins) {
            if (a - coin >= 0 && dp[a - coin] != INT_MAX) {
                if (dp[a] > 1 + dp[a - coin]) {
                    dp[a] = 1 + dp[a - coin];
                    chosen[a] = coin;
                }
            }
        }
    }

    if (dp[amount] == INT_MAX) {
        cout << "Not possible\n";
    }
    else {
        cout << "Minimum coins: " << dp[amount] << endl;
        cout << "Chosen coins: ";

        int temp = amount;
        while (temp > 0) {
            cout << chosen[temp] << " ";
            temp -= chosen[temp];
        }
    }
}
