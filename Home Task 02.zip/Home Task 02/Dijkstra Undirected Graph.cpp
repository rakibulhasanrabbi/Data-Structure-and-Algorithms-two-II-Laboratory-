#include <bits/stdc++.h>
using namespace std;

int main() {
    int V = 5;
    vector<pair<int,int>> adj[5];

    adj[0].push_back({1,2});
    adj[1].push_back({0,2});

    adj[0].push_back({3,6});
    adj[3].push_back({0,6});

    adj[1].push_back({2,3});
    adj[2].push_back({1,3});

    adj[1].push_back({4,5});
    adj[4].push_back({1,5});

    vector<int> dist(V, INT_MAX);
    priority_queue<pair<int,int>,
          vector<pair<int,int>>,
    greater<pair<int,int>>> pq;

    dist[0] = 0;
    pq.push({0,0});

    while(!pq.empty()) {
        int d = pq.top().first;
        int u = pq.top().second;
        pq.pop();

        for(auto x : adj[u]) {
            int v = x.first, w = x.second;

            if(dist[u] + w < dist[v]) {
                dist[v] = dist[u] + w;
                pq.push({dist[v], v});
            }
        }
    }

    for(int i=0;i<V;i++)
        cout << "0 -> " << i << " = " << dist[i] << endl;
}
