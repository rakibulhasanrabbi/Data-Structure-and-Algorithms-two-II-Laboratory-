#include <iostream>
using namespace std;

int countEven(int arr[], int l, int r) {
    if (l == r) {
        return (arr[l] % 2 == 0);
    }
    int mid = (l + r) / 2;
    return countEven(arr, l, mid) + countEven(arr, mid + 1, r);
}

int main() {
    int arr[] = {1, 2, 4, 7, 8};
    int n = 5;
    cout << countEven(arr, 0, n - 1);
}
