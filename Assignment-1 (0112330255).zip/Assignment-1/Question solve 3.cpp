#include <iostream>
using namespace std;

int findMax(int arr[], int l, int r) {
    if (l == r) return arr[l];
    int mid = (l + r) / 2;
    int left = findMax(arr, l, mid);
    int right = findMax(arr, mid + 1, r);
    return max(left, right);
}

int main() {
    int arr[] = {3, 9, 2, 15, 7};
    int n = 5;
    cout << findMax(arr, 0, n - 1);
}
