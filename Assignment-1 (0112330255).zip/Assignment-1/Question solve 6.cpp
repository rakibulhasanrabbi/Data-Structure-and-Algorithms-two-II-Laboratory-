#include <iostream>
using namespace std;

struct Student {
    string name;
    int id;
    float cgpa;
};

Student findTop(Student arr[], int l, int r) {

    if (l == r) return arr[l];

    int mid = (l + r) / 2;

    Student left = findTop(arr, l, mid);
    Student right = findTop(arr, mid + 1, r);

    if (left.cgpa > right.cgpa)
        return left;
    else
        return right;
}

int main() {
    Student s[] = {
        {"A", 101, 3.5},
        {"B", 102, 3.9},
        {"C", 103, 3.7}
    };

    int n = 3;

    Student top = findTop(s, 0, n - 1);

    cout << "Top Student: " << top.name
         << ", ID: " << top.id
         << ", CGPA: " << top.cgpa << endl;

    return 0;
}
