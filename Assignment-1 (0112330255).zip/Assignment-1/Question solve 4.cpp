#include <iostream>
using namespace std;

int majority(int arr[], int l, int r) {
    if (l == r) return arr[l];

    int mid = (l + r) / 2;
    int left = majority(arr, l, mid);
    int right = majority(arr, mid + 1, r);

    if (left == right) return left;

    int leftCount = 0, rightCount = 0;
    for (int i = l; i <= r; i++) {
        if (arr[i] == left) leftCount++;
        if (arr[i] == right) rightCount++;
    }

    return (leftCount > rightCount) ? left : right;
}

int main() {
    int arr[] = {2,2,1,2,3,2,2};
    int n = 7;
    cout << majority(arr, 0, n-1);
}
