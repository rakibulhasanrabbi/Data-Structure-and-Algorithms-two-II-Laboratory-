#include <iostream>
using namespace std;

int maxNonNegativeSum(int arr[], int n) {
    int maxSum = 0, currentSum = 0;

    for (int i = 0; i < n; i++) {
        if (arr[i] >= 0) {
            currentSum += arr[i];
            maxSum = max(maxSum, currentSum);
        } else {
            currentSum = 0;
        }
    }
    return maxSum;
}

int main() {
    int arr[] = {1, 2, -3, 4, 5, 6, -2};
    int n = 7;
    cout << maxNonNegativeSum(arr, n);
}
