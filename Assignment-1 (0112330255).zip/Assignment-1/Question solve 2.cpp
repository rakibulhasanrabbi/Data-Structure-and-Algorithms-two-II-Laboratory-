#include <iostream>
using namespace std;

bool isVowel(char c) {
    c = tolower(c);
    return (c=='a'||c=='e'||c=='i'||c=='o'||c=='u');
}

int countVowel(string s, int l, int r) {
    if (l == r) return isVowel(s[l]);
    int mid = (l + r) / 2;
    return countVowel(s, l, mid) + countVowel(s, mid + 1, r);
}

int main() {
    string s = "Hello World";
    cout << countVowel(s, 0, s.size()-1);
}
