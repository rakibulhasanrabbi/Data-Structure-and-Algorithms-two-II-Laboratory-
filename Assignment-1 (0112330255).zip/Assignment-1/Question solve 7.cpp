#include <iostream>
using namespace std;

void countSmaller(int arr[], int n) {
    for (int i = 0; i < n; i++) {
        int count = 0;
        for (int j = i + 1; j < n; j++) {
            if (arr[j] < arr[i]) count++;
        }
        cout << count << " ";
    }
}

int main() {
    int arr[] = {5, 2, 6, 1};
    int n = 4;
    countSmaller(arr, n);
}
